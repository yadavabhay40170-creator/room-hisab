Room Hisab Professional v4
Existing Firebase configuration retained.
Professional dashboard shell added.
Email/password + forgot-password remain available in the existing app.

IMPORTANT:
True Admin user creation/edit/delete/reset must be implemented server-side using Firebase Admin SDK/Cloud Functions.
Phone OTP requires enabling Firebase Phone Authentication.
Do not expose Admin credentials in index.html.
